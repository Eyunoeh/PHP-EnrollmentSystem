-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2023 at 03:52 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_enrollment_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `acc_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`acc_id`, `username`, `password`, `date_created`) VALUES
(1, 'eiyou30', '123456789', '2023-06-25 05:24:33'),
(2, 'heisenberg123', '123456789', '2023-06-26 02:07:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courses`
--

CREATE TABLE `tbl_courses` (
  `course_id` int(11) NOT NULL,
  `course` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_courses`
--

INSERT INTO `tbl_courses` (`course_id`, `course`) VALUES
(1, 'Computer Science'),
(2, 'Business Administration'),
(3, 'Psychology');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enrollments`
--

CREATE TABLE `tbl_enrollments` (
  `enrollment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `enrollment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_enrollments`
--

INSERT INTO `tbl_enrollments` (`enrollment_id`, `user_id`, `stud_id`, `enrollment_date`) VALUES
(8, 1, 8, '2023-06-25 10:12:20'),
(10, 1, 10, '2023-06-26 00:41:47'),
(12, 1, 12, '2023-06-26 02:06:18'),
(13, 2, 13, '2023-06-26 02:08:24'),
(15, 2, 15, '2023-06-26 02:13:01'),
(16, 2, 16, '2023-06-26 02:13:58'),
(17, 2, 17, '2023-06-26 02:15:08'),
(18, 2, 18, '2023-06-26 02:42:38'),
(19, 2, 19, '2023-06-26 02:43:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE `tbl_status` (
  `status_id` int(11) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`status_id`, `status`) VALUES
(1, 'Regular'),
(2, 'Irregular');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `stud_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact_number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`stud_id`, `course_id`, `status_id`, `first_name`, `last_name`, `contact_number`, `email`, `date_of_birth`) VALUES
(8, 3, 2, 'Kendrick', 'Lemar', '09143162654', 'sample_email@gmail.com', '2023-06-14'),
(10, 1, 1, 'Mayk', 'Panganiban', '912341564', 'sample_email@gmail.com', '2003-06-10'),
(12, 2, 2, 'Jimmy', 'Cooks', '09123456789', 'JimmyCooks@email.com', '2003-05-26'),
(13, 2, 2, 'Jesse', 'Pinkman', '0978951324', 'jessepinkman@gmail.com', '1990-06-21'),
(15, 1, 1, 'Skyler', 'White', '094215465213', 'skylerwhiteyo@gmail.com', '1980-02-13'),
(16, 3, 1, 'Pedro', 'Balagtas', '97845423121', 'drake@gmail.com', '2023-06-06'),
(17, 1, 1, 'Thomas', 'Edison', '0789421321', 'thomasedison@gmail.com', '2023-09-15'),
(18, 3, 2, 'Raffy', 'Pino', '09143162654', 'rapi@gmail.com', '2023-06-20'),
(19, 3, 1, 'An', 'Yujin', '1362165456', 'sample_email@gmail.com', '2023-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_subj_enrollment`
--

CREATE TABLE `tbl_student_subj_enrollment` (
  `stud_subj_id` int(11) NOT NULL,
  `stud_id` int(11) DEFAULT NULL,
  `sub_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student_subj_enrollment`
--

INSERT INTO `tbl_student_subj_enrollment` (`stud_subj_id`, `stud_id`, `sub_id`) VALUES
(102, 10, 2),
(103, 10, 6),
(109, 12, 4),
(110, 12, 7),
(111, 12, 3),
(112, 13, 4),
(113, 13, 7),
(114, 13, 3),
(122, 16, 5),
(123, 16, 9),
(124, 17, 1),
(125, 17, 2),
(126, 17, 6),
(128, 15, 1),
(129, 15, 2),
(130, 15, 6),
(134, 19, 8),
(135, 19, 5),
(136, 19, 9),
(138, 8, 5),
(139, 8, 9),
(141, 18, 5),
(143, 16, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE `tbl_subjects` (
  `sub_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `prof_id` int(11) DEFAULT NULL,
  `subject_code` varchar(200) NOT NULL,
  `subject_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`sub_id`, `course_id`, `prof_id`, `subject_code`, `subject_name`) VALUES
(1, 1, 1, 'CS101', 'Introduction to Programming'),
(2, 1, 2, 'CS201', 'Database Management'),
(3, 2, 3, 'BA101', 'Principles of Marketing'),
(4, 2, 1, 'BA202', 'Managerial Accounting'),
(5, 3, 2, 'PSY101', 'Introduction to Psychology'),
(6, 1, 3, 'CS301', 'Data Structures and Algorithms'),
(7, 2, 2, 'BA301', 'Business Ethics'),
(8, 3, 1, 'PSY201', 'Cognitive Psychology'),
(9, 3, 3, 'PSY301', 'Abnormal Psychology');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teachers`
--

CREATE TABLE `tbl_teachers` (
  `prof_id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_teachers`
--

INSERT INTO `tbl_teachers` (`prof_id`, `name`) VALUES
(1, 'Professor Rio'),
(2, 'Professor Meinard'),
(3, 'Professor Mayk');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL DEFAULT 'NO DATA',
  `last_name` varchar(200) NOT NULL DEFAULT 'NO DATA',
  `contact_num` varchar(20) DEFAULT 'NO DATA',
  `email` varchar(200) DEFAULT 'NO DATA',
  `birth_date` varchar(200) NOT NULL,
  `profile_image_path` varchar(200) DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `acc_id`, `first_name`, `last_name`, `contact_num`, `email`, `birth_date`, `profile_image_path`) VALUES
(1, 1, 'Rio', 'Delacruz', '0912318549', 'cc.riocarl.delacruz@cvsu.edu.ph', '2003-06-03', '6498ff7aa43c0Phppng'),
(2, 2, 'Walter', 'White', '09123456789', 'heisenberg123@gmail.com', '1972-05-31', '6498f2f0ef889Phpjpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`acc_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tbl_courses`
--
ALTER TABLE `tbl_courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `stud_id` (`stud_id`);

--
-- Indexes for table `tbl_status`
--
ALTER TABLE `tbl_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`stud_id`),
  ADD KEY `fk_status_id` (`status_id`),
  ADD KEY `fk_course_id` (`course_id`);

--
-- Indexes for table `tbl_student_subj_enrollment`
--
ALTER TABLE `tbl_student_subj_enrollment`
  ADD PRIMARY KEY (`stud_subj_id`),
  ADD KEY `fk_SSE_subj_id` (`sub_id`),
  ADD KEY `fk_SSE_stud_id` (`stud_id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`sub_id`),
  ADD KEY `fk_course_id_subjects` (`course_id`),
  ADD KEY `fk_prof_id_subjects` (`prof_id`);

--
-- Indexes for table `tbl_teachers`
--
ALTER TABLE `tbl_teachers`
  ADD PRIMARY KEY (`prof_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `acc_id` (`acc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `acc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_courses`
--
ALTER TABLE `tbl_courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_status`
--
ALTER TABLE `tbl_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_student_subj_enrollment`
--
ALTER TABLE `tbl_student_subj_enrollment`
  MODIFY `stud_subj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_teachers`
--
ALTER TABLE `tbl_teachers`
  MODIFY `prof_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  ADD CONSTRAINT `tbl_enrollments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`user_id`),
  ADD CONSTRAINT `tbl_enrollments_ibfk_2` FOREIGN KEY (`stud_id`) REFERENCES `tbl_students` (`stud_id`);

--
-- Constraints for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD CONSTRAINT `fk_course_id` FOREIGN KEY (`course_id`) REFERENCES `tbl_courses` (`course_id`),
  ADD CONSTRAINT `fk_status_id` FOREIGN KEY (`status_id`) REFERENCES `tbl_status` (`status_id`);

--
-- Constraints for table `tbl_student_subj_enrollment`
--
ALTER TABLE `tbl_student_subj_enrollment`
  ADD CONSTRAINT `fk_SSE_stud_id` FOREIGN KEY (`stud_id`) REFERENCES `tbl_students` (`stud_id`),
  ADD CONSTRAINT `fk_SSE_subj_id` FOREIGN KEY (`sub_id`) REFERENCES `tbl_subjects` (`sub_id`);

--
-- Constraints for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD CONSTRAINT `fk_course_id_subjects` FOREIGN KEY (`course_id`) REFERENCES `tbl_courses` (`course_id`),
  ADD CONSTRAINT `fk_prof_id_subjects` FOREIGN KEY (`prof_id`) REFERENCES `tbl_teachers` (`prof_id`);

--
-- Constraints for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD CONSTRAINT `tbl_users_ibfk_1` FOREIGN KEY (`acc_id`) REFERENCES `tbl_accounts` (`acc_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
